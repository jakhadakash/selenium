#!/usr/bin/env python3
"""
MSSQL Database Connection Test Script
Auto-installs dependencies if missing and tests database connectivity
"""

import sys
import subprocess
import json
import os
from datetime import datetime

# ============================================================================
# DEPENDENCY MANAGEMENT
# ============================================================================

def check_python_version():
    """Check if Python version is adequate"""
    version = sys.version_info
    print("="*70)
    print("Python Version Check")
    print("="*70)
    
    if version.major < 3 or (version.major == 3 and version.minor < 7):
        print(f"❌ ERROR: Python 3.7 or higher is required")
        print(f"   Current version: {version.major}.{version.minor}.{version.micro}")
        print("\nPlease upgrade Python:")
        print("   Download from: https://www.python.org/downloads/")
        return False
    
    print(f"✓ Python version: {version.major}.{version.minor}.{version.micro}")
    print("="*70)
    print()
    return True

def install_package(package):
    """Install a Python package using pip"""
    print(f"\nInstalling {package}...")
    print("-"*70)
    try:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", package, "--quiet"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE
        )
        print(f"✓ {package} installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install {package}")
        print(f"   Error: {e}")
        return False

def check_and_install_dependencies():
    """Check if required packages are installed, install if missing"""
    print("="*70)
    print("Checking Dependencies")
    print("="*70)
    
    required_packages = {
        'pyodbc': 'pyodbc==5.0.1'
    }
    
    all_installed = True
    
    for package, install_name in required_packages.items():
        try:
            __import__(package)
            print(f"✓ {package} is already installed")
        except ImportError:
            print(f"✗ {package} not found - installing...")
            if not install_package(install_name):
                print(f"\n❌ CRITICAL: Failed to install {package}")
                print(f"   Please install manually using:")
                print(f"   pip install {install_name}")
                all_installed = False
    
    print("="*70)
    print()
    return all_installed

# ============================================================================
# CONFIGURATION MANAGEMENT
# ============================================================================

def load_config():
    """Load database configuration from config.json"""
    config_file = 'config.json'
    
    print("="*70)
    print("Loading Configuration")
    print("="*70)
    
    if not os.path.exists(config_file):
        print(f"❌ ERROR: Configuration file '{config_file}' not found!")
        print("\nPlease create config.json with the following structure:")
        print("""
{
    "server": "your-server-name-or-ip",
    "database": "your-database-name",
    "username": "your-username",
    "password": "your-password",
    "port": "1433"
}
        """)
        return None
    
    try:
        with open(config_file, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        # Validate required keys
        required_keys = ['server', 'database', 'username', 'password']
        missing_keys = [key for key in required_keys if key not in config]
        
        if missing_keys:
            print(f"❌ ERROR: Missing required keys in config.json:")
            for key in missing_keys:
                print(f"   - {key}")
            return None
        
        print(f"✓ Configuration loaded successfully")
        print(f"   Server: {config['server']}")
        print(f"   Database: {config['database']}")
        print(f"   Username: {config['username']}")
        print("="*70)
        print()
        return config
        
    except json.JSONDecodeError as e:
        print(f"❌ ERROR: Invalid JSON in config.json")
        print(f"   {e}")
        return None
    except Exception as e:
        print(f"❌ ERROR: Failed to load config: {e}")
        return None

# ============================================================================
# ODBC DRIVER MANAGEMENT
# ============================================================================

def list_available_drivers():
    """List all available ODBC drivers"""
    try:
        import pyodbc
        print("="*70)
        print("Available ODBC Drivers")
        print("="*70)
        drivers = pyodbc.drivers()
        if drivers:
            for idx, driver in enumerate(drivers, 1):
                print(f"  {idx}. {driver}")
        else:
            print("  ⚠ WARNING: No ODBC drivers found!")
            print("\n  You need to install ODBC Driver for SQL Server:")
            print("  Windows: https://docs.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server")
            print("  Linux: sudo apt-get install unixodbc-dev msodbcsql17")
            print("  macOS: brew install msodbcsql17")
        print("="*70)
        print()
        return drivers
    except Exception as e:
        print(f"❌ Error listing drivers: {e}")
        print()
        return []

# ============================================================================
# DATABASE CONNECTION TEST
# ============================================================================

def test_mssql_connection(config):
    """Test MSSQL database connection"""
    import pyodbc
    
    print("="*70)
    print("MSSQL DATABASE CONNECTION TEST")
    print("="*70)
    print(f"Timestamp:    {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Server:       {config['server']}")
    print(f"Port:         {config.get('port', '1433')}")
    print(f"Database:     {config['database']}")
    print(f"Username:     {config['username']}")
    print(f"Driver:       {config.get('driver', 'ODBC Driver 17 for SQL Server')}")
    print("-"*70)
    
    # Get connection parameters
    driver = config.get('driver', 'ODBC Driver 17 for SQL Server')
    timeout = config.get('connection_timeout', 10)
    port = config.get('port', '1433')
    
    try:
        # Build connection string
        server_str = f"{config['server']},{port}"
        conn_str = (
            f"DRIVER={{{driver}}};"
            f"SERVER={server_str};"
            f"DATABASE={config['database']};"
            f"UID={config['username']};"
            f"PWD={config['password']}"
        )
        
        print(f"\nAttempting to connect (timeout: {timeout}s)...")
        print("Please wait...")
        
        # Establish connection
        conn = pyodbc.connect(conn_str, timeout=timeout)
        cursor = conn.cursor()
        
        print("\n✓ CONNECTION SUCCESSFUL!")
        print("="*70)
        
        # Get SQL Server version
        print("\nRetrieving server information...")
        print("-"*70)
        
        cursor.execute("SELECT @@VERSION as Version")
        version = cursor.fetchone()[0]
        # Extract first line of version
        version_line = version.split('\n')[0]
        print(f"SQL Server Version:\n  {version_line}")
        
        # Get database name
        cursor.execute("SELECT DB_NAME() as CurrentDB")
        current_db = cursor.fetchone()[0]
        print(f"\nCurrent Database: {current_db}")
        
        # Get server name
        cursor.execute("SELECT @@SERVERNAME as ServerName")
        server_name = cursor.fetchone()[0]
        print(f"Server Name: {server_name}")
        
        # Get server time
        cursor.execute("SELECT GETDATE() as CurrentTime")
        server_time = cursor.fetchone()[0]
        print(f"Server Time: {server_time}")
        
        # Get SQL Server edition
        cursor.execute("SELECT SERVERPROPERTY('Edition') as Edition")
        edition = cursor.fetchone()[0]
        print(f"SQL Server Edition: {edition}")
        
        # Test a simple query
        cursor.execute("SELECT 1 as TestQuery")
        test_result = cursor.fetchone()[0]
        print(f"\nTest Query Result: {test_result} (Expected: 1)")
        
        # Close connection
        cursor.close()
        conn.close()
        
        print("-"*70)
        print("\n" + "="*70)
        print("✓✓✓ CONNECTION TEST PASSED SUCCESSFULLY ✓✓✓")
        print("="*70)
        print("\nYour database connection is working correctly!")
        print("You can now use these credentials in your applications.")
        return True
        
    except pyodbc.Error as e:
        print("\n" + "="*70)
        print("❌ CONNECTION TEST FAILED")
        print("="*70)
        
        error_msg = str(e)
        print(f"\nError Details:")
        print(f"{error_msg}")
        
        print("\n" + "-"*70)
        print("TROUBLESHOOTING STEPS:")
        print("-"*70)
        print("1. Verify SQL Server is running")
        print("2. Check server name/IP address is correct")
        print("3. Verify port number (default: 1433)")
        print("4. Confirm username and password are correct")
        print("5. Enable TCP/IP in SQL Server Configuration Manager")
        print("6. Check Windows Firewall settings (allow port 1433)")
        print("7. Verify SQL Server allows remote connections")
        print("8. Try using IP address instead of server name")
        print("9. Check if SQL Server Browser service is running")
        print("10. Verify ODBC driver is installed correctly")
        
        if "Login failed" in error_msg:
            print("\n⚠ Specific Issue: LOGIN FAILED")
            print("   - Double-check username and password")
            print("   - Verify SQL Server authentication mode is enabled")
            print("   - Check if user account is not locked")
        elif "server was not found" in error_msg or "could not open" in error_msg:
            print("\n⚠ Specific Issue: SERVER NOT FOUND")
            print("   - Verify server name/IP address")
            print("   - Check network connectivity (ping the server)")
            print("   - Ensure SQL Server is running")
        elif "driver" in error_msg.lower():
            print("\n⚠ Specific Issue: DRIVER NOT FOUND")
            print("   - Install ODBC Driver for SQL Server")
            print("   - Available drivers are listed above")
        
        print("="*70)
        return False
        
    except Exception as e:
        print("\n" + "="*70)
        print("❌ UNEXPECTED ERROR")
        print("="*70)
        print(f"\nError: {e}")
        print("\nPlease check all settings and try again.")
        print("="*70)
        return False

# ============================================================================
# MAIN FUNCTION
# ============================================================================

def main():
    """Main function to orchestrate the connection test"""
    
    print("\n")
    print("*"*70)
    print("*" + " "*68 + "*")
    print("*" + " "*15 + "MSSQL CONNECTION TEST UTILITY" + " "*24 + "*")
    print("*" + " "*68 + "*")
    print("*"*70)
    print()
    
    # Step 1: Check Python version
    if not check_python_version():
        input("\nPress Enter to exit...")
        sys.exit(1)
    
    # Step 2: Check and install dependencies
    if not check_and_install_dependencies():
        print("\n❌ Failed to install required dependencies")
        print("Please install them manually and run this script again.")
        input("\nPress Enter to exit...")
        sys.exit(1)
    
    # Step 3: List available drivers
    drivers = list_available_drivers()
    if not drivers:
        print("⚠ WARNING: No ODBC drivers found!")
        print("The connection test may fail without proper ODBC drivers.")
        print()
    
    # Step 4: Load configuration
    config = load_config()
    if config is None:
        input("\nPress Enter to exit...")
        sys.exit(1)
    
    # Step 5: Test connection
    success = test_mssql_connection(config)
    
    # Final summary
    print("\n" + "="*70)
    if success:
        print("RESULT: ✓ TEST COMPLETED SUCCESSFULLY")
    else:
        print("RESULT: ❌ TEST FAILED - Please review errors above")
    print("="*70)
    print()
    
    # Exit with appropriate code
    sys.exit(0 if success else 1)

# ============================================================================
# ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠ Test interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
